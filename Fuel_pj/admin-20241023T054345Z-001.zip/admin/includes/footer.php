 <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Fuel Delivery Management System 2022</span>
            
          </div>
        </footer>